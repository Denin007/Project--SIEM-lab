# INV-002 — Lateral Movement Detection & Trace

**Date:** Lab simulation  
**Severity:** High  
**Status:** Resolved  
**Analyst:** Denin Sajan

---

## Summary

A lateral movement scenario was simulated from a compromised endpoint in the corporate LAN segment (`10.0.1.0/24`) attempting to reach the server segment (`10.0.2.0/24`). Zabbix SIEM detected anomalous inter-segment authentication attempts. The movement path was traced through Windows event logs and Wireshark packet captures, and detection gaps in the existing ruleset were identified and remediated.

---

## Alert Details

| Field | Value |
|---|---|
| Alert Name | Privileged Account Usage — Unusual Source |
| Source Host | `10.0.1.12` (WIN10-WS02) |
| Target Host | `10.0.2.10` (LAB-DC01) |
| Event IDs Observed | 4624 (Successful Logon), 4672 (Special Privileges Assigned), 4648 (Explicit Credential Use) |
| Logon Type | Type 3 (Network) |
| Alert Severity | High |

---

## Background — Simulation Setup

The lateral movement scenario was initiated from WIN10-WS02, simulating a compromised endpoint where an attacker had obtained local administrator credentials. The goal was to test whether the SIEM would detect:

1. Credential use across network segments
2. Unusual authentication patterns from a workstation to a domain controller
3. Service enumeration activity before and after access

---

## Investigation Steps

### Step 1 — Alert Triage

Zabbix triggered a "Privileged Account Used from Unusual Source" alert — Event ID 4672 was observed on LAB-DC01, but the source was a workstation IP (`10.0.1.12`) rather than a known admin host.

Initial triage confirmed:
- The account used was a domain administrator account
- The source host (WIN10-WS02) is a standard workstation — no reason for admin access to the DC
- The logon time was outside business hours (simulated overnight)

**Verdict: True positive. Escalation warranted.**

---

### Step 2 — Log Collection

Pulled Windows Security Event logs from both the source and target hosts.

**On WIN10-WS02 (source):**
```
Event ID: 4648 — Explicit Credential Use
Account Used: LAB\Administrator
Target Server: LAB-DC01.lab.local
Process: cmd.exe
Time: 23:14:32
```

**On LAB-DC01 (target):**
```
Event ID: 4624 — Successful Logon
Logon Type: 3 (Network)
Source IP: 10.0.1.12
Account: LAB\Administrator
Time: 23:14:33

Event ID: 4672 — Special Privileges Assigned
Account: LAB\Administrator
Privileges: SeDebugPrivilege, SeImpersonatePrivilege
Time: 23:14:33
```

---

### Step 3 — Network Traffic Analysis

Wireshark capture from the server segment VLAN was reviewed for the relevant timeframe.

**Observations:**
- SMB traffic (port 445) from `10.0.1.12` to `10.0.2.10` — consistent with lateral movement via SMB
- NTLM authentication handshake observed in the capture
- Post-authentication: net.exe commands observed querying domain group membership
- No outbound traffic to external IPs — movement contained within the lab network

**Wireshark filter used:**
```
ip.src == 10.0.1.12 && ip.dst == 10.0.2.10
```

---

### Step 4 — Attack Path Reconstruction

| Step | Action | Evidence |
|---|---|---|
| 1 | Attacker gains access to WIN10-WS02 | Assumed — simulation start point |
| 2 | Local credential dump simulated | Starting condition |
| 3 | Domain admin credentials obtained | Starting condition |
| 4 | SMB connection initiated to LAB-DC01 | Wireshark: SMB on port 445 |
| 5 | Successful authentication with domain admin creds | Event ID 4624 on DC |
| 6 | Special privileges assigned | Event ID 4672 on DC |
| 7 | Domain group enumeration via net.exe | Process creation logs |
| 8 | Zabbix alert triggered | 47 seconds after step 5 |

---

### Step 5 — Detection Gap Analysis

During the investigation, one significant gap was identified:

**Gap:** The initial credential dump on WIN10-WS02 (step 2) was not detected. The SIEM had no rule monitoring for LSASS memory access (Event ID 4656/4663 on lsass.exe) — a common indicator of credential harvesting.

**Action taken:** Added a new Zabbix trigger monitoring for process access to `lsass.exe` from unexpected processes. This would detect credential dumping tools like Mimikatz in future scenarios.

---

### Step 6 — Containment (Simulated)

In a real environment, the response would be:

1. **Immediately isolate** WIN10-WS02 from the network segment
2. **Reset** the domain administrator password
3. **Review** all other workstations for signs of the same credential use
4. **Escalate** to L2 analyst with the full investigation timeline
5. **Preserve** forensic evidence — memory image, event log exports, Wireshark capture
6. **Review** DC for any changes made during the attacker's access window (new accounts, GPO changes, scheduled tasks)

---

## Detection Rule Assessment

| Rule | Performance |
|---|---|
| Privileged account from unusual source | ✅ Triggered correctly |
| Unusual logon hours | ✅ Triggered correctly |
| SMB lateral movement detection | ⚠️ Not present — added after this investigation |
| LSASS access monitoring | ❌ Not present — added after this investigation |

---

## Rules Added Following This Investigation

**New Rule — SMB Lateral Movement:**
```
Name: SMB Connection from Workstation to Server
Trigger: SMB (port 445) traffic from 10.0.1.0/24 to 10.0.2.0/24
Severity: Medium
Action: Alert + log source and destination
```

**New Rule — LSASS Access:**
```
Name: Suspicious LSASS Process Access
Trigger: Event ID 4656/4663 targeting lsass.exe from non-system process
Severity: High
Action: Immediate alert
```

---

## Lessons Learned

1. **Logon Type 3 from a workstation to a DC is inherently suspicious** — it should almost never happen in normal operations and is a reliable lateral movement indicator
2. **Event ID 4672 is high signal** — special privileges being assigned immediately after a logon from an unusual source is strong evidence of compromise
3. **LSASS monitoring is essential** — credential dumping is the enabler of lateral movement; detecting it earlier would have caught this at step 2 rather than step 5
4. **VLAN segmentation slowed but did not stop** the movement — the attacker had valid domain credentials which were accepted across segments. Network segmentation alone is insufficient without strong credential hygiene and monitoring

---

## Evidence

- Windows Event Log export (DC): `evidence/INV-002-dc-event-logs.evtx`
- Windows Event Log export (WS02): `evidence/INV-002-ws02-event-logs.evtx`
- Wireshark capture: `evidence/INV-002-smb-capture.pcap`
- Screenshot — Zabbix alert: `screenshots/INV-002-zabbix-alert.png`
- Screenshot — Wireshark SMB traffic: `screenshots/INV-002-wireshark-smb.png`
