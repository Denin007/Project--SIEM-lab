# Screenshots

This folder contains screenshots from the lab environment documenting key configurations, alerts, and investigation findings.

## Index

| File | Description |
|---|---|
| `zabbix-dashboard.png` | Zabbix SIEM main dashboard showing active alerts |
| `active-directory-structure.png` | AD organisational unit structure |
| `network-topology-diagram.png` | Visual network topology |
| `INV-001-zabbix-alert.png` | Brute force alert in Zabbix dashboard |
| `INV-003-alert-volume-before.png` | Alert volume before rule tuning |
| `INV-003-alert-volume-after.png` | Alert volume after 18% FP reduction |
| `wireshark-c2-pattern.png` | Wireshark capture showing C2 beaconing pattern |
| `gpo-audit-policy.png` | Group Policy audit settings |

> Screenshots will be added as the lab documentation is completed.
